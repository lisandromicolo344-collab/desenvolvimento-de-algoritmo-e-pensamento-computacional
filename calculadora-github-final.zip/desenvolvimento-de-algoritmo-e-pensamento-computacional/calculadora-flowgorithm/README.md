# Calculadora no Flowgorithm - 20 Funções

**Atividade:** Desenvolvimento de Algoritmo e Pensamento Computacional - Calculadora com 20 funções no Flowgorithm

**Aluno:** Lisandro Micolo

**Curso:** Desenvolvimento de Algoritmo e Pensamento Computacional

---

## Objetivo do Programa

Desenvolver, utilizando o Flowgorithm, uma calculadora com 20 funções diferentes, aplicando os conceitos de lógica de programação, entrada e saída de dados, variáveis, operadores e estruturas de decisão. O programa deve apresentar um menu interativo permitindo ao usuário escolher a operação desejada.

## Descrição Resumida do Funcionamento

O programa inicia exibindo um menu numerado de 1 a 20 com todas as operações disponíveis. O usuário digita o número da opção desejada (Input). Através de estruturas condicionais (If), o fluxograma direciona para o bloco correspondente à função escolhida. Em cada função, o programa solicita via Output/Input os dados necessários, realiza o processamento com Assign (cálculos), e exibe o resultado final com Output. Há validações como divisão por zero e classificação automática no IMC.

Fluxo: Menu -> Escolha -> Entrada de dados -> Processamento -> Saída do resultado.

## Relação das 20 Funções Implementadas

1.  **Soma** - Soma de dois números
2.  **Subtração** - Subtração de dois números
3.  **Multiplicação** - Multiplicação de dois números
4.  **Divisão** - Divisão com validação de divisor zero
5.  **Média Aritmética** - Média de dois valores
6.  **Porcentagem** - Calcula X% de um valor
7.  **Regra de Três Simples** - Calcula proporcionalidade
8.  **Conversão de Temperatura** - Celsius para Fahrenheit (F = C*9/5 + 32)
9.  **Conversão de Unidades** - Metros para Quilômetros
10. **Cálculo de Área de Figuras Geométricas [OBRIGATÓRIA]** - Sub-menu com 4 opções: Quadrado (lado²), Retângulo (b*h), Círculo (π*r²) e Triângulo (b*h/2)
11. **Cálculo de Perímetro** - Perímetro do quadrado (4*lado)
12. **Cálculo de Volume** - Volume do cubo (lado³)
13. **Cálculo de Juros Simples** - J = C * i * t / 100
14. **Cálculo de Desconto** - Preço final com desconto
15. **Cálculo de Velocidade Média** - Vm = distância / tempo
16. **Cálculo de Consumo** - Consumo km/l
17. **Identificação de Número Par ou Ímpar** - Usa operador %
18. **Comparação entre Valores** - Maior entre dois números
19. **Cálculo de Potência** - base ^ expoente
20. **Cálculo de IMC - Índice de Massa Corporal [OBRIGATÓRIA]** - IMC = peso / altura² com classificação automática (Abaixo do peso, Peso normal, Sobrepeso, Obesidade)

> **Indicação das Funções Obrigatórias:** Conforme solicitado, as funções obrigatórias são a **Função 10 - Área de Figuras Geométricas** e a **Função 20 - IMC**.

## Instruções Básicas para Execução

1.  Acesse http://www.flowgorithm.org/ e baixe o Flowgorithm (Windows)
2.  Instale e abra o programa
3.  No Flowgorithm, vá em File > Open e selecione o arquivo `calculadora.fprg`
4.  Clique no botão de Play (ou aperte F5) para executar
5.  No console, digite o número da operação desejada de 1 a 20
6.  Digite os valores solicitados
7.  Visualize o resultado no console
8.  Para gerar código em C/Java/Python: Source Code Viewer (F12)

## Estrutura do Projeto

```
desenvolvimento-de-algoritmo-e-pensamento-computacional/
└── calculadora-flowgorithm/
    ├── calculadora.fprg (código fonte do Flowgorithm)
    └── README.md (esta documentação)
```

## Critérios Atendidos

- [x] 20 funções diferentes
- [x] Cálculo de IMC
- [x] Cálculo de Área
- [x] Menu de opções
- [x] Entrada de dados
- [x] Processamento e saída
- [x] Uso de variáveis
- [x] Uso de condicionais (If/Else)
- [x] Fluxograma organizado
